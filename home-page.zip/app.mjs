import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import session from "express-session";
import bcrypt from "bcryptjs";



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = `file:${path.resolve(__dirname, "../prisma/store.db").replace(/\\/g, "/")}`;
}
import express from "express";


// process.env.DATABASE_URL = `file:${path.join(__dirname, "../prisma/store.db")}`;

import prisma from "./prismaClient.js";
import { PrismaClient } from "@prisma/client/extension";

import SQLiteStoreFactory from "connect-sqlite3";
// import {sqlite3} from "sqlite3"



const app = express();
const PORT = process.env.PORT || 3000;

const publicPath = path.join(__dirname, "public");
console.log(
  "Serving static from:",
  publicPath,
  "Exists?",
  fs.existsSync(publicPath)
);
app.use(express.static(publicPath));

app.get("/", (req, res) => {
  res.sendFile(path.join(publicPath, "index.html"));
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.locals.hasLowStock = false;
app.locals.lowStockProducts = [];
app.locals.page = 1;
app.locals.totalPages = 1;


app.use(express.urlencoded({ extended: true }));

app.use(express.json());
const SQLiteStore = SQLiteStoreFactory(session);

app.use(
  session({
   store: new SQLiteStore({ db: "sessions.sqlite", dir: process.env.SESSION_DB_PATH || "." }),
    secret: "939a41a93d5b32936dce8307489b26231133c17bf4872c32c8c941122f61b73a5ab4991c581a57aa10a973d868ce843470ec37e46a596e5d4985385408d0a3f9", // change this to a real secret
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 3, // 2 hours
      sameSite: "lax", // allows navigating across tabs on same domain
    },
  })
);

// function sessionAuth(req, res, next) {
//   if (req.session.user) {
//     next(); // session valid → continue
//   } else {
//     res.status(401).send({ message: "Session expired. Please log in again." });
//   }
// }

import loginRoutes from "./routes/login.js";
import dashboardRoutes from "./routes/dashboard.js";
import salesTodayRoutes from "./routes/sales-today.js";
import settingsRoutes from "./routes/settings.js";
import notesRoutes from "./routes/notes.js";
// import cartRoutes from "./routes/cart.js";

// app.use("/", cartRoutes);
app.use("/", notesRoutes);
app.use("/auth", loginRoutes);
app.use("/", dashboardRoutes);
app.use("/", salesTodayRoutes);
app.use("/settings", settingsRoutes);

app.use(async (req, res, next) => {
  const lowStockProducts = await prisma.product.findMany({
    where: { quantity: { lt: 5 } },
  });
  res.locals.hasLowStock = lowStockProducts.length > 0;
  res.locals.lowStockProducts = lowStockProducts;
  next();
});

// Serve the login page

// DATABASE_URL="file:../prisma/store.db"

// Middleware
// app.use((req, res, next) => {
//   if (req.session.cart && req.method === "GET" && req.path.startsWith("/purchase")) {
//     (async () => {
//       for (const item of req.session.cart) {
//         const product = await Product.findById(item._id);
//         if (product) {
//           product.quantity += item.quantity;
//           await product.save();
//         }
//       }
//       req.session.cart = []; // clear cart
//     })();
//   }
//   next();
// });
// Put this AFTER your other route imports and before app.listen

app.get("/access-denied", (req, res) => {
  res.render("alert", {
    message: "Access denied! Only admins can access this.",
  });
});

// app.get('/login', (_, res) => {
//   res.render('login', { error: '' });
// });
app.get("/signup", (_, res) => {
res.render("signup")
});

app.get("/addProduct", (_, res) => {
  res.render("addProduct", { title: "Add Product" });
});
//  app.get("/login",(req,res)=> {
//   res.render('login', {error: ''})
//  })

const SESSION_DURATION_MS = 1000 * 60 * 30; // 30 minutes
// const SESSION_DURATION_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

// const router = express.Router();
// Adjust the path as needed

// GET Login page

// app.get('/login', (req, res) => {
//   res.render('login', { error: '' });
// });

// // POST Login form
// app.post('/login', async (req, res) => {
//   const { username, password } = req.body;

//   // Example simple authentication (replace with your real logic)
//   // const user = await User.findOne({ username });

// const user = await prisma.user.findUnique({where : {username}})

//   if (!user) {
//     return res.render('login', { error: 'User not found' });
//  }

//   const isPasswordValid = await bcrypt.compare(password, user.password);
//   if (!isPasswordValid) {
//     return res.render('login', { error: 'Invalid Password' });
//   } else {
//     req.session.user = { id: user.id, username: user.username,isAdmin: user.isAdmin };

//     res.redirect('/dashboard');
//   }
// });

app.post("/products/add", async (req, res) => {
  try {
    const { pname, price, quantity, reorderLevel, size, description } =
      req.body;

    const category = req.body.categories;

    const product = await prisma.product.create({
      data: {
        pname,
        price: Number(price),
        quantity: Number(quantity),
        reorderLevel: Number(reorderLevel),
        size,
        description,
        category,
      },
    });
    const products =  await prisma.product.findMany()
    res.render("products", {
      title: "Products",
      products
    })
   
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.get("/products/:id", async (req, res) => {
  try {
    const product = await prisma.product.findUnique({
      where: { id: Number(req.params.id) },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/products/update/:id", async (req, res) => {
  try {
    const product = await prisma.product.findUnique({
      where: { id: Number(req.params.id) },
    });
    res.json(product)
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


app.post("/products/edit/:id", async (req, res) => {
  try {
    const { pname, price, size, quantity, reorderLevel, description } =
      req.body;

    //   await Product.findByIdAndUpdate(req.params.id, {
    //     pname,
    //     price,
    //     size,
    //     quantity,
    //     reorderLevel,
    //     description,
    //   },
    //    { upsert: true, new: true, setDefaultsOnInsert: true }
    // );

    const product = await prisma.product.update({
      where: { id: Number(req.params.id) },
      data: { pname, price: Number(price), size, quantity: Number(quantity), reorderLevel: Number(reorderLevel), description },

      // create: { pname, price, size, quantity, reorderLevel, description },
    });

    res.redirect("/search/product"); // or wherever your search page is
  } catch (err) {
    // res.status(500).send('Update failed');
  }
});

app.get("/students/update/:id", async (req, res) => {
  try {
    // const student = await Student.findById(req.params.id);
    const student = await prisma.student.findUnique({
      where: { id: Number(req.params.id) },
    });
    res.json(student);
  } catch (err) {
    console.error("Error fetching student:", err);
    res.status(500).json({ message: "Error fetching student" });
  }
});

app.get("/students/view/:id", async (req, res) => {
  try {
    // const student = await Student.findById(req.params.id);
    const student = await prisma.student.findUnique({
      where: { id: Number(req.params.id) },
      include: { purchases: true }, 
    });
     const page = parseInt(req.query.page) || 1;
     const perPage = 10;
     const skip = (page - 1) * perPage

     const purchases = student.purchases

   
     const totalPurchases = purchases.count
     const totalPages = Math.ceil(totalPurchases/perPage)


    // res.json(student);
    res.render("viewStudent", {
      title: "View Student",
      student,
      perPage,
      purchases,
      currentPage: page,
      totalPages
      
    });
  } catch (err) {
    console.error("Error fetching student:", err);
    
    res.render("error", { err });
  }
});

app.post("/students/edit/:id", async (req, res) => {
  try {

    const { studentName, studentClass, admissionNumber,gender } = req.body;
   
    await prisma.student.update({
      where: { id: Number(req.params.id) },
      data: {
        studentName,
        studentClass,
        admissionNumber,
        gender,
      },
    });

    return res.redirect("/students");
  } catch (err) {
    console.error("Error updating student:", err);
  }
});

app.get("/students", (req, res) => {
  res.render("students", { title: "Student" });
});

// app.post('/addStudent', async (req, res) => {
//   const {  firstName = '',
//     middleName = '',
//     lastName = '',
//      class: studentClass,admissionNumber } = req.body;

//   // Trim and combine the name
//   const fullName = middleName
//     ? `${firstName.trim()} ${middleName.trim()} ${lastName.trim()}`
//     : `${firstName.trim()} ${lastName.trim()}`;

//   const student = new Student({
//     name: fullName,
//     class: studentClass,
//     admissionNumber: admissionNumber.trim(),

//   });

//   try {
//     await student.save();
//     res.redirect('/students');
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Error saving student');
//   }
// });

app.post("/students/add", async (req, res) => {
  try {
    const {
      firstName = "",
      middleName = "",
      lastName = "",
      admissionNumber,
    } = req.body;
    const studentClass = req.body.studentClass;
    const gender = req.body.gender;
    const existingStudent = await prisma.student.findUnique({
      where: { admissionNumber: admissionNumber.trim() },
    });
    if(existingStudent) {
      res.render('addStudent',{
        err: "Admission Number already exists",
        title: "Add Student"
        
      })
    } 
    // Trim and combine the name
    const studentName = middleName
      ? `${firstName.trim()} ${middleName.trim()} ${lastName.trim()}`
      : `${firstName.trim()} ${lastName.trim()}`;

    const student = await prisma.student.create({
      data: { studentName, studentClass, admissionNumber,gender },
    });
    // console.log(studentClass)
    res.redirect("/students");
  } catch (err) {
    console.log(err);
    // res.status(500).json({ error: err.message });
    
  }
});

app.get("/addStudent", (req, res) => {
  res.render("addStudent", { title: "Add Student",err:''});
});

// app.get("/search/student", async (req, res) => {
//   try {
//     const query = req.query.studentSearchQuery;
//     const queryOption = req.query.filterBy || 'studentName'
//     const page = parseInt(req.query.page) || 1;   
//     const perPage = 3;                          
//     const skip = (page - 1) * perPage;
//    let whereClause = {}
//    if( queryOption === 'studentName') {
//     whereClause = {
//       studentName: {
//         contains: query,
//         // mode: "insensitive"
//       },
//     }
//     } else if (queryOption ==='studentClass') {
//       whereClause = {
//         studentClass: {
//           contains: query,
//           // mode: "insensitive"
//         },
//       }
//     } else if (queryOption === 'admissionNumber') {
//       whereClause = {
//         admissionNumber: {
//           contains: Number(query),
//           // mode: "insensitive"
//         },
//       }
//     } 
//     const studentQuery = query ? query.trim() : "";
   
//     const students = studentQuery
//       ? await prisma.student.findMany({
//           where: whereClause,
//           orderBy: {id: 'asc'}
//         })
//       : await prisma.student.findMany({
//         skip: skip,
//         take: perPage,
//         orderBy: {id: 'asc'}
//       });

// const totalStudents = await prisma.student.count();
//   const totalPages = Math.ceil(totalStudents / perPage);


//     res.render("searchStudent", {
//       title: "Search Student",
//       students,
//       currentPage: page,
//       totalPages,
//       studentSearchQuery: query,
//     });
//   } catch (err) {
//     console.error("Error rendering search page:", err);
//     res.status(500).send("Server error");
//   }
// });

app.get('/search/student', async (req, res) => {
  const { studentSearchQuery, filterBy, page = 1 } = req.query;
  const itemsPerPage = 10;
  const skip = (page - 1) * itemsPerPage;

  let students = [];
  let total = 0;

  if (studentSearchQuery && filterBy) {
    const where = {};

    if (filterBy === 'studentName') {
      where.studentName = { contains: studentSearchQuery};
    } else if (filterBy === 'studentClass') {
      where.studentClass = { contains: studentSearchQuery};
    } else if (filterBy === 'admissionNumber') {
      where.admissionNumber = { contains: studentSearchQuery};
    }

    students = await prisma.student.findMany({
      where,
      skip,
      take: itemsPerPage,
    });

    total = await prisma.student.count({ where });
  } else {
    students = await prisma.student.findMany({ skip, take: itemsPerPage });
    total = await prisma.student.count();
  }

  const totalPages = Math.ceil(total / itemsPerPage);

  res.render('searchStudent', {
    title: 'Search Student',
    students,
    studentSearchQuery,
    filterBy,
    currentPage: parseInt(page),
    totalPages,
  });
});


// app.get("/searchStudent", async (req, res) => {
//   try {
//     const students = await prisma.student.findMany();
//     let totalPages;
//     let page;
//     res.render("searchStudent", {
//       students,
//       currentPage:page,
//       totalPages,
//       title: "Search Students",
//     });
//   } catch (err) {
//     console.error("Error rendering search page:", err);
//     res.status(500).send("Server error");
//   }
// });

//handle search request

app.get("/search/product", async (req, res) => {
  try {
    const name = req.query.name || "";
    const page = parseInt(req.query.page) || 1;
    const perPage = 10;
    const skip = (page -1)* perPage
    

    const products = name ?
    await prisma.product.findMany({
      where: { pname: { contains: name } },
    })
    : await prisma.product.findMany({
      skip: skip,
      take: perPage,
      orderBy: {id :'asc'}
    })

    const totalProducts = await prisma.product.count()
    const totalPages = Math.ceil(totalProducts/perPage)

    res.render("search", {
      title: "Search Products",
      products,
      searchQuery: name,
      totalPages,
      currentPage: page,
    });
  } catch (err) {
    console.error("Error rendering search page:", err);
    res.status(500).send("Server error");
  }
});

app.get("/purchase/:id", async (req, res) => {
  try {
    //  const student = await Student.findById(req.params.id);
    //  const products = await Product.find();

    const student = await prisma.student.findUnique({
      where: { id: Number(req.params.id) },
    });
    const products = await prisma.product.findMany();

    res.render("purchase", {
      title: "Purchase Product",
      products,
      student,
      cart:  req.session.cart || [],
      searchQuery: "",
    });
  } catch (err) {
    console.error("Error fetching products or student:", err);
    return res.status(500).send("Server error");
  }
});

app.get("/searchProducts", async (req, res) => {
  try {
    const name = req.query.name || "";
    const studentId = req.query.studentId; // now always comes through
    let products = {};

    if (name) {
      products = await prisma.product.findMany({
        where: { pname: { contains: name} },
      });
    } else {
      products = await prisma.product.findMany();
    }

    const student = studentId
      ? await prisma.student.findUnique({ where: { id: Number(studentId) } })
      : null;

    res.render("purchase", {
      title: "Purchase Product",
      products,
      student: student || {},
      cart:  req.session.cart || [],
      searchQuery: name,
    });
  } catch (err) {
    console.error("Error rendering purchase page:", err);
    res.status(500).send("Server error");
  }
});

app.post("/cart/add/:id", async (req, res) => {
  try {
    const qty = parseInt(req.body.quantity, 10);
    const studentId = req.body.studentId;
    if (!req.session.cart) req.session.cart = [];

    // const product = await Product.findById(req.params.id);3

    const product = await prisma.product.findUnique({
      where: { id: Number(req.params.id) },
    });

    if (!product) return res.status(404).send("Product not found");

    // if (qty > product.quantity) {
    //   return res.send(`Only ${product.quantity} in stock`);
    // }
    // product.quantity -= qty;
    //  await product.save();

    // await prisma.product.update({
    //   where: { id: Number(req.params.id) },
    //   data: { quantity: product.quantity },
    // });

    const cartItem = req.session.cart.find(
      (item) => item.id.toString() === product.id.toString()
    );
    if (cartItem) {
      cartItem.quantity += qty;
    } else {
      req.session.cart.push({
        id: product.id,
        pname: product.pname,
        price: product.price,
        size: product.size,
        description: product.description,
        quantity: qty,
      });
    }

    res.redirect(`/purchase/${studentId}?search=${req.query.search || ""}`);
  } catch (err) {
    console.error(err);
    res.status(500).send("Error adding to cart");
  }
});

app.post("/cart/checkout/:studentId", async (req, res) => {
  try {
    const cart = req.session.cart || [];
     for (const element of cart) {
      await prisma.product.update({
        where: { id: Number(element.id) },
        data: {
          quantity: {
            decrement: element.quantity
          }
        },
      });
    }
    if (cart.length === 0) return res.send("Cart is empty");

    const studentId = req.params.studentId;
  
    const student = await prisma.student.findUnique({
      where: { id: Number(studentId) },
    });

    if (student) {
      await prisma.student.update({
        where: { id: Number(studentId) },
        data: {
          purchases: {
            create: cart.map((item) => ({
              productId: item.id,
              name: item.pname,
              price: item.price,
              size: item.size,
              description: item.description,
              quantity: item.quantity,
            })),
          },
        },
      });
    }

    req.session.cart = []; // clear cart

    res.redirect(`/students/view/${studentId}`);

  } catch (err) {
    console.error(err);
    res.status(500).send("Checkout error");
  }
});

app.post("/cart/cancel/:id", async (req, res) => {
  try {
    const cart = req.session.cart || [];
    for (const item of cart) {
      // const product = await Product.findById(item._id);

      const product = await prisma.product.findUnique({
        where: { id: Number(item.id) },
      });

      //  const

      if (product) {
        product.quantity += item.quantity;
        // return stock
        await prisma.product.update({
          where: { id: Number(item.id) },
          data: { quantity: product.quantity },
        });
      }
    }

    req.session.cart = []; // clear cart
    res.redirect(`/purchase/${req.params.id}`);
 
  } 
  catch (err) {
    console.error(err);
    return res.status(500).send("Error updating stock");
  }

  try {
    // const cart = req.session.cart || [];
     } catch (err) {
    console.error(err);
    res.status(500).send("Error cancelling cart");
  }
});

app.get("/remark/:id", async (req, res) => {
  try {
    // const data = await Student.findById(req.params.id);

    const data = await prisma.student.findUnique({
      where: { id: Number(req.params.id) },
    });

    res.json(data);
  } catch (err) {
    console.error("Error fetching student:", err);
    res.status(500).json({ message: "Error fetching student" });
  }
});

app.post("/update-remark/:id", async (req, res) => {
  try {
    const { remark } = req.body;
    // const student = await Student.findById(req.params.id);
    const student = await prisma.student.findUnique({
      where: { id: Number(req.params.id) },
    });
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    await prisma.student.update({
      where: { id: Number(req.params.id) },
      data: { remark },
    });

    // student.remark = remark;
    // await student.save();

    res.redirect(`/students/view/${student.id}`);
  } catch (err) {
    console.error("Error updating remark:", err);
    // res.status(500).json({ message: 'Error updating remark' });
  }
});

app.get("/reminders", async (req, res) => {
  //  const lowStockItems = await Product.find({
  //   $expr: { $lte: ["$quantity", "$reorderLevel"] }
  // });

  // const lowStockItems = await prisma.product.findMany({
  //   where : {
  //     quantity: {
  //       lte: prisma.product.reorderLevel
  //     }
  //   }
  // })
  const products = await prisma.product.findMany();
  const lowStockItems = products.filter((p) => p.quantity <= p.reorderLevel);

  res.render("reminders", {
    title: "Reminders",
    products: lowStockItems,
  });
});

// app.delete('/students/:id',async (req, res) => {
//   const studentId = req.params.id;
//   // Student.findByIdAndDelete(studentId)

// await prisma.student.delete({
//   where : {id: Number(studentId)}
// })

//   .then(result => {
//     res.json()
//   })
//   .catch(err => {
//     console.log(err)
//     })
// })
app.get('/delete/:id',(req,res) => {

  // res.status(500).json()
})

app.delete("/students/delete/:id", async (req, res) => {
  try {
    await prisma.student.delete({ where: { id: Number(req.params.id) } });
    res.json({ redirect: "/students" });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error deleting student");
  }
});

app.delete("/products/delete/:id", async (req, res) => {
  const id = req.params.id;

  try {
    await prisma.product.delete({ where: { id: Number(id) } });
    res.json({ redirect: "/products" });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error deleting product");
  }
});

// Handle login form submission
// app.post('/login',  async (req, res) => {
//   const { username, password } = req.body;

//   const user = await User.findOne({ username });
//   if (!user) {
//     return res.status(401).json({ message: "User Not Found" });
//   }

//   const isPasswordValid = await bcrypt.compare(password, user.password);
//   if (!isPasswordValid) {
//     return res.status(401).json({ message: "Invalid Password" });
//   } else {
//  res.status(200).json({ message: "Login successful", user });
//   // res.render('dashboard', { title: 'Dashboard', user:username });
//   }
// });

app.post("/signup", async (req, res) => {
  const { username, password, cpassword, isAdmin } = req.body;

  if (password !== cpassword) {
    return res.status(400).json({ message: "Passwords do not match" });
  }

  try {
    // const existingUser = await User.findOne({ username });
    const existingUser = await prisma.user.findUnique({ where: { username } });

    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // const newUser = new User({
    //   username,
    //   password: hashedPassword,
    //   isAdmin: Boolean(isAdmin) // directly store boolean
    // });

    // await newUser.save();

    await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        isAdmin: Boolean(isAdmin),
      },
    });

    res.status(200).json({ message: "Signup successful" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error registering user" });
  }
});

app.get("/products", (_, res) => {
  res.render("products", { title: "Products" });
});

app.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Error destroying session:", err);
      return res.status(500).send("Could not log out.");
    }

    res.clearCookie("connect.sid", { path: "/" });
    res.redirect("/auth/login?forceReload=true");
  });
});

// app.get('*', (_, res) => {
//   res.sendFile(path.join(__dirname, 'build', 'index.html'));
// });

// app.get('/dashboard', (_, res) => {
//   res.render('dashboard', { title: 'Dashboard',user:username });``
// });

// Start server
// Start server
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
export default app;
