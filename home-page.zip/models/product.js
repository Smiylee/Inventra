import mongoose from 'mongoose';
const Schema = mongoose.Schema;
const productSchema = new Schema ({
    pname:{
        type:String,
        required:true
    },
    price:{
        type:Number,
        required:true
    },
    quantity:{
        type:Number,
        default: 0 ,
        required:true
    },
    reorderLevel:{
        type:Number,
        default:0,
        required:true
    },
    size: {
        type:String,
        default: "N/A",
        
    },
    description:
    {
        type:String,
        required:false
    },
    
    createdAt:{
        type:Date,
       default:Date.now()
    }

}, {timestamps:true});

const Product = mongoose.model('Product',productSchema)
export default Product;

