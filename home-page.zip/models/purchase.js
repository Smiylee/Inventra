import mongoose from 'mongoose';

const Schema = mongoose.Schema;

const purchaseSchema = new Schema({

    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  quantity: { type: Number, required: true, min: 1 },
  totalPrice: { type: Number, required: true },
  purchaseDate: { type: Date, default: Date.now }
})

const Purchase = mongoose.model('Purchase', purchaseSchema);
export default Purchase;