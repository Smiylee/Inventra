import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const studentSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  
  class: {
    type: String,
    enum: ['JSS1', 'JSS2', 'JSS3', 'SSS1', 'SSS2', 'SSS3'], 
    required: false
  },

  balance: {
    type: Number,
    required: false
  },
  remark : {
   type: String,
    required: false,
  },
    admissionNumber: {
    type: String,
    required: false,
    unique: true 
  },
purchases: [
        {
            productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
            pname: String,
            price: Number,
            size: String,
            description: String,
            quantity: Number,
            date: { type: Date, default: Date.now }
        }
    ],

  createdAt: {
    type: Date,
    default: Date.now
  }

}, { timestamps: true });

const Student = mongoose.model('Student', studentSchema);
export default Student;
