import pkg from '@prisma/client';
const { PrismaClient } = pkg;
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Debug log
console.log("📂 Using DB URL:", process.env.DATABASE_URL);

const prisma = new PrismaClient({
  log: ["error", "warn", "info"],
});

export default prisma;
