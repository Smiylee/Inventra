import express from 'express';
import bodyParser from 'body-parser';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
import { dirname } from 'path';
const app = express();
const PORT = 3000;
import Product from './models/product.js';
import mongoose from 'mongoose';
import { sign } from 'crypto';





mongoose.connect('mongodb://127.0.0.1:27017/storeDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("MongoDB connected ✅");
}).catch(err => {
  console.log("MongoDB connection error ❌", err);
});



// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // Serve static HTML/CSS files
app.set('view engine', 'ejs'); // Set EJS as the templating engine

// Serve the login page
app.get('/', (_, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/addProduct', (_, res) => {
  res.render('addProduct', { title: 'Add Product' });
})


app.post('/addProduct',(req,res) => {
  const { pname,price,quantity,size,description } = req.body;
  const product = new Product({
    pname,
    price,
    quantity,
    size,
    description
  });
  console.log("Form Data:", req.body);

  product.save()
    .then(() => {
      res.redirect('/products');
    })
    .catch(err => {
      console.error(err);
      res.status(500).send('Error saving product to database.');
    });
})




//handle search request

app.get('/search', async (req, res) => {
  try {
    const name = req.query.name || '';
      // const size = req.query.size || '';

    const query = {};
    if (name) query.pname = new RegExp(name, 'i');
    // if (size) query.size = size;

    const products = await Product.find(query);

    res.render('search', {
      title: 'Search Products',
      products,
      searchQuery: name,
     
    });

  } catch (err) {
    console.error('Error rendering search page:', err);
    res.status(500).send('Server error');
  }
});


app.delete('/products/:id', (req, res) => {
  const id = req.params.id;
  Product.findByIdAndDelete(id)
  .then(result => {
    res.json({redirect:'/products'})
  })
  .catch(err => {
    console.log(err)
    })
})

// Handle login form submission
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Example: basic check
  if (username === 'admin' && password === '1234') {
    res.render('dashboard', { user: username });
  } else {
    res.send(`<h3>Login failed. <a href="/">Try again</a></h3>`);
  }
});




app.get('/products', (_, res) => {
  res.render('products', { title: 'Products'});
});

// app.get('*', (_, res) => {
//   res.sendFile(path.join(__dirname, 'build', 'index.html'));
// });



// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
