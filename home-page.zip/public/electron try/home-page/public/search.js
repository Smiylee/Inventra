document.getElementById('searchBtn').addEventListener('click', () => {
    const searchQuery = document.getElementById('search').value;
  
    if (!searchQuery.trim()) return;
  
    fetch(`/search?pname=${encodeURIComponent(searchQuery)}`)
      .then(res => res.json())
      .then(data => {
        const resultContainer = document.getElementById('result-container');
        if (data.found) {
          resultContainer.innerHTML = `
            <h3 id="result">Product Name: ${data.product.pname}</h3>
            <h3>Quantity: ${data.product.quantity}</h3>
            <h3>Price: ${data.product.price}</h3>
            <h3>Description: ${data.product.description}</h3>
            <br>
            <button id="deleteBtn" class="edit-btn">Delete</button>
            <button id="updateBtn" class="edit-btn">Update</button>
          `;
        } else {
          resultContainer.innerHTML = `<h2 id="result">Product not found</h2>`;
        }
      })
      .catch(err => {
        console.error(err);
        document.getElementById('result-container').innerHTML = `<h2 id="result">Error searching for product.</h2>`;
      });
  });
  