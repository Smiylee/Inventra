const passwordInput = document.getElementById("password");
const togglePassword = document.getElementById("togglePassword");

togglePassword.addEventListener("click", () => {
  const isPassword = passwordInput.type === "password";
  passwordInput.type = isPassword ? "text" : "password";
  
  // Optional: Change the eye icon (if you use different icons)
  togglePassword.textContent = isPassword ? "🙈" : "👁️";
});


const c_passwordInput = document.getElementById("cpassword");
const c_togglePassword = document.getElementById("ctogglePassword");

c_togglePassword.addEventListener("click", () => {
  const c_isPassword = c_passwordInput.type === "password";
  c_passwordInput.type = c_isPassword ? "text" : "password";
  
  // Optional: Change the eye icon (if you use different icons)
  c_togglePassword.textContent = c_isPassword ? "🙈" : "👁️";
});
