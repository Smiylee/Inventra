// const express = require('express');
// const router = express.Router();


const errorM = document.getElementById('errorM');
const passwordInput = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');

togglePassword.addEventListener('click', () => {
const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password'
    togglePassword.textContent = isPassword ? '🙉':'👁️' 
})

// const loginForm = document.getElementById('loginForm');







// loginForm.addEventListener('submit',async function (e) {
// e.preventDefault(); 
// // Prevent the default form submission


// try {
// const res = await fetch('http://localhost:3000/login', {
// method:'POST',
// headers: {'Content-Type': 'application/json'},
// body: JSON.stringify({
//     username: document.getElementById('username').value,
//     password: document.getElementById('password').value
// })
// })

// const data = await res.json();
// if (!res.ok) {
// // Show alert if error
// // alert(data.message);
// errorM.textContent = data.message;
// errorM.style.color = 'red';
// } else {
// // Success
// // alert('Login successful!');
// errorM.textContent = '';
// window.location.href = '/dashboard'; // Redirect to dashboard or any other page
//  // Redirect to dashboard or any other page
//  // Optional redirect
// }
// } catch (error) {
// console.error('Error:', error);
// alert('An error occurred. Please try again later.');
// }



// });