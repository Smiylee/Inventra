  // script.js
document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.getElementById("sidebar");
  const toggleBtn = document.getElementById("toggleBtn");
  const backBtn = document.getElementById("backBtn");
  const forwardBtn = document.getElementById("forwardBtn");

  // Collapse / Expand Sidebar
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
  });
  // Update Student Modal
  const modalContainer = document.createElement('div');
  modalContainer.id = 'student-modal-container';
  modalContainer.style.display = 'none';
  modalContainer.style.position = 'fixed';
  modalContainer.style.top = '0';
  modalContainer.style.left = '0';
  modalContainer.style.width = '100vw';
  modalContainer.style.height = '100vh';
  modalContainer.style.background = 'rgba(0,0,0,0.5)';
  modalContainer.style.justifyContent = 'center';
  modalContainer.style.alignItems = 'center';
  modalContainer.style.zIndex = '1000';
  document.body.appendChild(modalContainer);

  function showStudentModal(formHTML) {
    modalContainer.innerHTML = `
      <div style="background:#fff;padding:24px;border-radius:8px;max-width:400px;margin:auto;position:relative;">
        ${formHTML}
        <button type="button" id="closeStudentModal" style="position:absolute;top:8px;right:8px;">&times;</button>
      </div>
    `;
    modalContainer.style.display = 'flex';
    document.getElementById('closeStudentModal').onclick = () => {
      modalContainer.style.display = 'none';
      modalContainer.innerHTML = '';
    };
  }
 const supdateButtons = document.querySelectorAll('#supdateBtn');

  supdateButtons.forEach(button => {
    button.addEventListener('click', async function () {
      const studentId = this.getAttribute('data-doc');
      try {
        const response = await fetch(`/students/update/${studentId}`);
        const student = await response.json();

        const formHTML = `
          <h3>Edit Student: ${student.studentName}</h3>
          <form method="POST" action="/students/edit/${student.id}" id="edit-form">
            <label>Name:</label>
            <input type="text" name="studentName" value="${student.studentName}" required /><br><br>
            <label>Class:</label>
            <input type="text" name="studentClass" value="${student.studentClass}" required /><br><br>
            <label>Admission Number:</label>
            <input type="text" name="admissionNumber" value="${student.admissionNumber}" required /><br><br>
            <label>Gender:</label>
            <input type="text" name="gender" value="${student.gender}" required /><br><br>
            <button type="submit">Save Changes</button>
            <button type="button" id="cancelStudentModal">Cancel</button>
          </form>
        `;

        showStudentModal(formHTML);

        document.getElementById('cancelStudentModal').onclick = () => {
          modalContainer.style.display = 'none';
          modalContainer.innerHTML = '';
        };
      } catch (err) {
        console.error('Error loading Student data:', err);
        alert('Failed to load Student details.');
      }
    });
  });

  // Back & Forward Buttons
  backBtn.addEventListener("click", () => {
    window.history.back();
  });

  forwardBtn.addEventListener("click", () => {
    window.history.forward();
  });
});



//search functionality

  const deleteButtons = document.querySelectorAll('#deleteBtn');
  deleteButtons.forEach(button => {
    button.addEventListener('click', function() {
      const docId = this.getAttribute('data-doc');
      fetch(`/delete/${docId}`, {
        method: 'DELETE'
      })
      
      
      .then(() => {
        const confirmDelete = confirm('Are you sure you want to delete this product?');
        if (confirmDelete) {
          fetch(`/products/delete/${docId}`, {
        method: 'DELETE'
          })
          .then(response => {
        if (response.ok) {
          alert('Product deleted successfully!');
          location.reload(); 
        } else {
          alert('Failed to delete product.');
        }
          })
          .catch(error => console.error('Error:', error));
        }
      })
      .catch(error => console.error('Error:', error));
    });
  });

function showModal(id) {
  document.getElementById(id).style.display = 'block';
  document.getElementById(id).classList.add('active');
} 




 const updateButtons = document.querySelectorAll('#updateBtn');

updateButtons.forEach(button => {
    button.addEventListener('click', function() {
      const docId = this.getAttribute('data-doc');
      showModal('edit-form-container');
    });
  });

  

  // updateButtons.forEach(button => {
  //   button.addEventListener('click', async function () {
  //     const productId = this.getAttribute('data-doc');

  //     try {
  //       const response = await fetch(`/product/${productId}`);
  //       const product = await response.json();

  //       const formHTML = `
  //         <h3>Edit Product: ${product.pname}</h3>
  //         <form method="POST" action="/products/edit/${product._id}" id="edit-form">
  //           <label>Name:</label>
  //           <input type="text" name="pname" value="${product.pname}" required /><br><br>

  //           <label>Price:</label>
  //           <input type="number" name="price" value="${product.price}" required /><br><br>

  //           <label>Size:</label>
  //           <input type="text" name="size" value="${product.size}" required /><br><br>

  //           <label>Quantity:</label>
  //           <input type="number" name="quantity" value="${product.quantity}" required /><br><br>

  //            <label>Re-Order Level:</label>
  //           <input type="number" name="reorderLevel" value="${product.reorderLevel}" required /><br><br>

  //           <label>Description:</label><br>
  //           <textarea name="description" rows="4" cols="50">${product.description}</textarea><br><br>

  //           <button type="submit">Save Changes</button>
  //           <button type="button" onclick="document.getElementById('edit-form-container').innerHTML = '';">Cancel</button>
  //         </form>
  //       `;

  //       document.getElementById('edit-form-container').innerHTML = formHTML;

  //        document.getElementById('edit-form-container').scrollIntoView({ behavior: 'smooth' });

  //     } catch (err) {
  //       console.error('Error loading product data:', err);
  //       alert('Failed to load product details.');
  //     }
  //   });
  // });

 // search ended



//  searchStudent.ejs


const sdeleteButtons = document.querySelectorAll('#sdeleteBtn');
  sdeleteButtons.forEach(button => {
    button.addEventListener('click', function() {
      const docId = this.getAttribute('data-doc');
      fetch(`/delete/${docId}`, {
        method: 'GET'

      })
      
      
      .then((response) => {
        const confirmDelete = confirm('Are you sure you want to delete this Student Record?');
        if (confirmDelete) {
          fetch(`/students/${docId}`, {
        method: 'DELETE'
          })
          .then(response => {
        if (response.ok) {
          alert('Student Record deleted successfully!');
          location.reload(); 
        } else {
          alert('Failed to delete Student.');
        }
          })
          .catch(error => console.error('Error:', error));
        }
      })
      .catch(error => console.error('Error:', error));
    });
  });
  
  


//  const supdateButtons = document.querySelectorAll('#supdateBtn');

  // supdateButtons.forEach(button => {
  //   button.addEventListener('click', async function () {
  //     const studentId = this.getAttribute('data-doc');

  //     try {
  //       const response = await fetch(`/students/${studentId}`);
  //       const student = await response.json();

  //       const formHTML = `
  //         <h3>Edit Student: ${student.studentName}</h3>
  //         <form method="POST" action="/students/edit/${student.id}" id="edit-form">
  //           <label>Name:</label>
  //           <input type="text" name="studentName" value="${String(student.studentName)}" required /><br><br>
  //           <label>Class:</label>
  //           <input type="text" name="studentClass" value="${student.studentClass}" required /><br><br>

  //           <label>Admission Number:</label>
  //           <input type="text" name="admissionNumber" value="${student.admissionNumber}" required /><br><br>

  //           <button type="submit">Save Changes</button>
  //           <button type="button" onclick="document.getElementById('edit-form-container').innerHTML = '';">Cancel</button>
  //         </form>
    
  //   `;

  //       document.getElementById('edit-form-container').innerHTML = formHTML;
  //       showProductModal('formHTML')

  //       // document.getElementById('edit-form-container').scrollIntoView({ behavior: 'smooth' });

  //     } catch (err) {
  //       console.error('Error loading Student data:', err);
  //       alert('Failed to load Student details.',err);
  //     }
  //   });
  // });


const viewButtons = document.querySelectorAll('#viewBtn');
const productModalContainer = document.createElement('div');
productModalContainer.id = 'product-modal-container';
productModalContainer.style.display = 'none';
productModalContainer.style.position = 'fixed';
productModalContainer.style.top = '0';
productModalContainer.style.left = '0';
productModalContainer.style.width = '100vw';
productModalContainer.style.height = '100vh';
productModalContainer.style.background = 'rgba(0,0,0,0.5)';
productModalContainer.style.justifyContent = 'center';
productModalContainer.style.alignItems = 'center';
productModalContainer.style.zIndex = '1000';
document.body.appendChild(productModalContainer);

function showProductModal(formHTML) {
  productModalContainer.innerHTML = `
    <div style="background:#fff;padding:24px;border-radius:8px;max-width:400px;margin:auto;position:relative;">
      ${formHTML}
      <button type="button" id="closeProductModal" style="position:absolute;top:8px;right:8px;">&times;</button>
    </div>
  `;
  productModalContainer.style.display = 'flex';
  document.getElementById('closeProductModal').onclick = () => {
    productModalContainer.style.display = 'none';
    productModalContainer.innerHTML = '';
  };
}

updateButtons.forEach(button => {
  button.addEventListener('click', async function () {
    const productId = this.getAttribute('data-doc');
    try {
      const response = await fetch(`/products/update/${productId}`);
      const product = await response.json();

      const formHTML = `
        <h3>Edit Product: ${product.pname}</h3>
        <form method="POST" action="/products/edit/${product.id}" id="edit-form">
          <label>Name:</label>
          <input type="text" name="pname" value="${product.pname}" required /><br><br>
          <label>Price:</label>
          <input type="number" name="price" value="${product.price}" required /><br><br>
          <label>Size:</label>
          <input type="text" name="size" value="${product.size}" required /><br><br>
          <label>Quantity:</label>
          <input type="number" name="quantity" value="${product.quantity}" required /><br><br>
          <label>Re-Order Level:</label>
          <input type="number" name="reorderLevel" value="${product.reorderLevel}" required /><br><br>
          <label>Description:</label><br>
          <textarea name="description" rows="4" cols="50">${product.description}</textarea><br><br>
          <button type="submit">Save Changes</button>
          <button type="button" id="cancelProductModal">Cancel</button>
        </form>
      `;

      showProductModal(formHTML);

      document.getElementById('cancelProductModal').onclick = () => {
        productModalContainer.style.display = 'none';
        productModalContainer.innerHTML = '';
      };
    } catch (err) {
      console.error('Error loading product data:', err);
      alert('Failed to load product details.');
    }
  });
});
viewButtons.forEach(button => {
  button.addEventListener('click', async function () {
    const studentViewId = this.getAttribute('data-doc');
    try {
      // Redirect to the view page for the student
      window.location.href = `/students/view/${studentViewId}`;
    } catch (err) {
      console.error('Error loading Student data:', err);
      alert('Failed to load Student details.');
    }
  });
});



// viewStudent.ejs

const changeRemarkButton = document.getElementById('changeRemark');
      const remarkFormContainer = document.getElementById('remarkForm');
        const remarkElement = document.getElementById('remarkh3');


        changeRemarkButton.addEventListener("click",async () => {
            const studentId = changeRemarkButton.getAttribute('data-doc');
        const response = await fetch(`/remark/${studentId}`);
        const data = await response.json();
        const formHTML = `
            <form method="POST" action="/update-remark/${studentId}">
                <label for="remark">Remark:</label>
                <input type="textarea" id="remark" name="remark" value="${data.remark}" required>
                <button type="submit">Update Remark</button>
                <button type="button" onclick="document.getElementById('remarkForm').innerHTML = '';">Cancel</button>
            </form>
        `;
        remarkFormContainer.innerHTML = formHTML;
        })


        // settings.js
  // const settingsBtn = document.getElementById('settings-btn');
  // const content = document.querySelector('.dropdown-content');
  // settingsBtn.addEventListener('click', () => {
  //   content.style.display = content.style.display === 'block' ? 'none' : 'block';
  // });

  // window.addEventListener('click', e => {
  //   if (!btn.contains(e.target) && !content.contains(e.target)) {
  //     content.style.display = 'none';
  //   }
  // });


  // function add_category() {
    
  // }

  
