const passwordInput = document.getElementById("password");
  const togglePassword = document.getElementById("togglePassword");
  togglePassword.addEventListener("click", () => {
    const isPassword = passwordInput.type === "password";
    passwordInput.type = isPassword ? "text" : "password";
    togglePassword.textContent = isPassword ? "🙈" : "👁️";
  });

  const c_passwordInput = document.getElementById("cpassword");
  const c_togglePassword = document.getElementById("ctogglePassword");
  c_togglePassword.addEventListener("click", () => {
    const isPassword = c_passwordInput.type === "password";
    c_passwordInput.type = isPassword ? "text" : "password";
    c_togglePassword.textContent = isPassword ? "🙈" : "👁️";
  });

  const form = document.getElementById("actualSignupForm");
  const errorMessage = document.getElementById("errorMessage");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = passwordInput.value;
    const confirmPassword = c_passwordInput.value;
    const isAdmin = document.getElementById("isAdmin").checked;

    try {
      
      const res = await fetch("/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, cpassword: confirmPassword, isAdmin })
      });

      const data = await res.json();

      if (!res.ok) {
        errorMessage.textContent = data.message;
        errorMessage.style.color = "red";
      } else {
        window.location.href = "/auth/login";
      }
    } catch (err) {
      errorMessage.textContent = "Something went wrong: " + err.message;
      errorMessage.style.color = "red";
    }
  });