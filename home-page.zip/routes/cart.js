import express from "express";
const router = express.Router();

let cart = []; // shared in-memory cart

// Add or increase item
router.post("/cart/add/:id", (req, res) => {
  const { productId, name, price } = req.body;
  const studentId = req.body.studentId;
  const quantity = parseInt(req.body.quantity) || 1;

  const existing = cart.find(item => item.productId === productId);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ productId, name, price, quantity });
  }

  res.redirect(`/purchase/${studentId}?search=${req.query.search || ""}`);
});

// Decrease item quantity by one
router.post("/minus-one/:productId", (req, res) => {
  const productId = req.params.productId;
  const index = cart.findIndex(item => item.productId === productId);

  if (index !== -1) {
    cart[index].quantity -= 1;

    // Remove item if quantity becomes 0
    if (cart[index].quantity <= 0) {
      cart.splice(index, 1);
    }
  }

  res.redirect(`/purchase/${studentId}?search=${req.query.search || ""}`);
});

// Show cart
// router.get("/cart", (req, res) => {
//   res.render("cart", { cart });
// });

export default router;
