import express from 'express';
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const router = express.Router();

router.get('/dashboard', async (req, res) => {
  if (!req.session.user) return res.redirect('/auth/login');

  try {
    // Fetch students and their purchases
    const students = await prisma.student.findMany({
      include: { purchases: true }
    });

    // Define today's date range
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    let todaySales = [];

    students.forEach(student => {
      student.purchases.forEach(p => {
        if (p.date >= startOfDay && p.date <= endOfDay) {
          todaySales.push({
            studentName: student.studentName,
            pname: p.name,
            quantity: p.quantity,
            price: p.price,
          });
        }
      });
    });

    // Get product list for stock count
    const products = await prisma.product.findMany();

    const lowStockCount = products.filter(p => p.quantity <= p.reorderLevel).length;
      const hasLowStock = lowStockCount.length > 0;
    const salesCount = todaySales.length;
    const totalRevenue = todaySales.reduce((sum, s) => sum + s.price * s.quantity, 0);
    const totalStudents = students.length;

    // Render dashboard
    res.render('dashboard', {
      title: 'Dashboard',
      user: req.session.user.username,
      salesCount,
      totalRevenue,
      lowStockCount,
      hasLowStock,
      totalStudents,
    });

  } catch (err) {
    console.error(err);
    res.status(500).send('Error loading dashboard');
  }
});

export default router;
