import express from 'express';
import { PrismaClient } from "@prisma/client";
import session from 'express-session';
import e from 'express';

const prisma = new PrismaClient();
const router = express.Router();


router.get("/notes", async(req, res) => {
    if (!req.session.user) return res.redirect('/auth/login');
    try {
        const notes = await prisma.note.findMany({
            orderBy: { createdAt: 'desc' }
        });
        res.render("notes", { title: "Notes", user: req.session.user.username, notes });
    } catch (err) {
        console.error(err);
        res.status(500).send("Error loading notes");
    }
});
router.post("/notes/add", async(req, res) => {
    if (!req.session.user) return res.redirect('/auth/login');
    const { title, content } = req.body;
    try {
        await prisma.note.create({
            data: { title, content }
        });
        res.redirect("/notes");
    }
    catch (err) {
        console.error(err);
        res.status(500).send("Error creating note");
    }
}
);
router.post("/notes/delete/:id", async(req, res) => {
    if (!req.session.user) return res.redirect('/auth/login');
    const noteId = Number(req.params.id);
    try {
        await prisma.note.delete({
            where: { id: noteId }
        });
        res.redirect("/notes");
    } catch (err) {
        console.error(err);
        res.status(500).send("Error deleting note");
    }
});

export default router;
