// import express from 'express';
// import bodyParser from 'body-parser';
// import path from 'path';

// import mongoose from 'mongoose';
// import Purchase from '../models/purchase.js';
// import Product from '../models/product.js'; 
// import Student from '../models/student.js'; 


// const router = express.Router();


// router.use(bodyParser.json());

// router.use(bodyParser.urlencoded({ extended: true }));

// router.get('/purchase', async (req, res) => {
//   try {
//     const products = await Product.find();
//     const students = await Student.find();
//     res.render('purchase', { products, students });
//   } catch (error) {
//     console.error('Error fetching products or students:', error);
//     res.status(500).send('Internal Server Error');
//   }
// });
