// routes/dashboard.js
import express from "express";
// import Student from "../models/student.js";

// const express = require("express");
// const Student = require("../models/student");

import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

const router = express.Router();

router.get("/sales-today", async (req, res) => {
  try {
    // get today's start and end times
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    // fetch all students
    // const students = await Student.find({});
    const students = await prisma.student.findMany({include: {purchases: true}})

    // collect all today's purchases
    let todaySales = [];
    students.forEach(student => {
      student.purchases.forEach(p => {
        if (p.date >= startOfDay && p.date <= endOfDay) {
          todaySales.push({
            studentName: student.studentName,
            pname: p.pname,
            quantity: p.quantity,
            price: p.price,
            total: p.price * p.quantity,
            time: p.date
          });
        }
      });
    });

    // calculate total revenue
const totalRevenue = todaySales.reduce((sum, s) => {
  return sum + (s.price * s.quantity);
}, 0);

    res.render("salesToday", { title:"Today's Sales",sales: todaySales, totalRevenue });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error fetching today's sales");
  }
});

export default router;
// module.exports = router;
