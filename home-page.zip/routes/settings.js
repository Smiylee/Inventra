
import express from 'express';
// import Student from '../models/student.js';
// import Product from '../models/product.js';
// import User from '../models/user.js';
import multer from 'multer';
import fs from 'fs';
// import myds from "myds";

// const express = require("express");
// const Student = require("../models/student");
// const Product = require("../models/product");
// const User = require("../models/user");
// const multer = require("multer");
// const fs = require("fs");
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();


const router = express.Router();
const upload = multer({ dest: 'uploads/' });

// Middleware to check admin
function isAdmin(req, res, next) {
  if (req.session.user && req.session.user.isAdmin) return next();
  return res.redirect('/access-denied');

}

// Export data
router.get('/export', isAdmin, async (req, res) => {
  // const students = await Student.find({});
  const students = await prisma.student.findMany({})
  // const products = await Product.find({});
   const products = await prisma.product.findMany({})
  // const users = await User.find({});
   const users = await prisma.user.findMany({})

  const data = { students, products, users };
  // const  filename = "storeBackup"+myds.getTimeDate().toString();
  res.setHeader('Content-Disposition', 'attachment; filename=storeBackup.json');
  res.setHeader('Content-Type', 'application/json');
  res.send(JSON.stringify(data, null, 2));
});

// Import data
router.post('/import', isAdmin, upload.single('backup'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).send('No file uploaded');

    const rawData = fs.readFileSync(req.file.path);
    const data = JSON.parse(rawData);
    const {students, products,users} = data
    // Clear and import
    await prisma.student.deleteMany({});
    await prisma.product.deleteMany({});
    await prisma.user.deleteMany({});
    await prisma.student.createMany({ data: students });
    await prisma.product.createMany({ data: products });
    await prisma.user.createMany({ data: users });

    fs.unlinkSync(req.file.path);
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error importing data');
  }
});

// Reset data
router.post('/reset', isAdmin, async (req, res) => {
  try {
    await prisma.student.deleteMany({});
    await prisma.product.deleteMany({});
    await prisma.user.deleteMany({});
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error resetting data');
  }
});

export default router;
// module.exports = router;
